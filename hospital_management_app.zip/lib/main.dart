import 'package:flutter/material.dart';

void main() => runApp(HospitalApp());

class HospitalApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hospital Management',
      home: Scaffold(
        appBar: AppBar(title: Text('Hospital Dashboard')),
        body: Center(child: Text('Welcome to Abu Hussain Hospital')),
      ),
    );
  }
}